ROOT = "/"
INDEX = "/index"
INDEX_FORMAT = "/index/{0}"
SIZE = "/size"
BACKUP = "/backup"
HEADER = {'Content-Type': "application/json",
          'Accept': 'application/json'}
